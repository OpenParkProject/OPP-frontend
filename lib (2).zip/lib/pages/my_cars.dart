import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MyCarsPage extends StatefulWidget {
  const MyCarsPage({super.key});

  @override
  State<MyCarsPage> createState() => _MyCarsPageState();
}

class _MyCarsPageState extends State<MyCarsPage> {
  final _plateController = TextEditingController();
  final _modelController = TextEditingController();
  final _brandController = TextEditingController();

  List<Map<String, String>> userPlates = [];
  bool loadingPlates = true;
  String? _feedbackMessage;

  @override
  void initState() {
    super.initState();
    _fetchPlates();
  }

  Future<void> _fetchPlates() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('access_token');
      final dio = Dio(BaseOptions(baseUrl: "http://openpark.com/api/v1"));

      final response = await dio.get(
        "/users/me/cars",
        options: Options(headers: {
          "Authorization": "Bearer $token",
        }),
      );

      final data = response.data;
      final fetchedCars = (data as List)
          .map((car) => {
            "plate": car['plate']?.toString().toUpperCase() ?? '',
            "model": car['model']?.toString() ?? '',
            "brand": car['brand']?.toString() ?? ''
          })
          .toList();

      setState(() {
        userPlates = fetchedCars;
        loadingPlates = false;
      });
    } catch (e) {
      String msg = "❌ Failed to load vehicle list.";
      if (e is DioException && e.response?.data is Map) {
        final data = e.response?.data;
        msg = data?['error']?.toString() ?? data?['detail']?.toString() ?? msg;
      }
      setState(() {
        loadingPlates = false;
        _feedbackMessage = msg;
      });
    }
  }

  Future<void> _addCar() async {
    final plate = _plateController.text.trim().toUpperCase();
    final model = _modelController.text.trim();
    final brand = _brandController.text.trim();

    if (plate.isEmpty || brand.isEmpty || model.isEmpty) {
      setState(() => _feedbackMessage = "❗ Please fill all fields.");
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('access_token');
      final dio = Dio(BaseOptions(baseUrl: "http://openpark.com/api/v1"));

      await dio.post(
        "/users/me/cars",
        data: {
          "plate": plate,
          "brand": brand,
          "model": model,
        },
        options: Options(headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        }),
      );

      setState(() {
        _feedbackMessage = "✅ Vehicle $plate registered successfully.";
        _plateController.clear();
        _brandController.clear();
        _modelController.clear();
      });

      await _fetchPlates();
    } catch (e) {
      String msg = "❌ Failed to register vehicle.";
      if (e is DioException && e.response?.data is Map) {
        final data = e.response?.data;
        msg = "❌ ${data?['error'] ?? data?['detail'] ?? 'Unknown error'}";
      }
      setState(() => _feedbackMessage = msg);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("My Vehicles")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            if (loadingPlates)
              CircularProgressIndicator()
            else if (userPlates.isNotEmpty) ...[
              Text("Registered Plates:", style: TextStyle(fontWeight: FontWeight.bold)),
              ...userPlates.map((car) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(car['plate'] ?? '', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text(
                    "${car['brand'] ?? ''} ${car['model'] ?? ''}".trim(),
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                ],
              ),
            )),
              Divider(),
            ],
            Text("Add a new vehicle"),
            TextField(controller: _plateController, decoration: InputDecoration(labelText: "License Plate")),
            TextField(controller: _brandController, decoration: InputDecoration(labelText: "Brand")),
            TextField(controller: _modelController, decoration: InputDecoration(labelText: "Model")),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _addCar,
              child: Text("Add Vehicle"),
            ),
            if (_feedbackMessage != null) ...[
              SizedBox(height: 20),
              Text(_feedbackMessage!, style: TextStyle(color: Colors.blue)),
            ],
          ],
        ),
      ),
    );
  }
}